function validateSudokuboard(sudoboardString){
    return 'helt utfylt, ingen feil';
}